import com.sang.Service.EmployeeService;
import com.sang.dao.Impl.EmployeeDaoImpl;
import com.sang.pojo.Employee;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

/**
 * @author slzstart
 * @create 2022-08-20 11:22
 */
public class MyTest {
    @Test
    public void test1() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        JdbcTemplate template = context.getBean("jdbcTemplate", JdbcTemplate.class);
        System.out.println(template);
    }

    @Test
    public void test2() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeService employeeService = context.getBean("employeeService", EmployeeService.class);
    }

    @Test
    public void test3() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeDaoImpl employeeDaoImpl = context.getBean("employeeDaoImpl", EmployeeDaoImpl.class);
        List<Employee> all = employeeDaoImpl.getAll();
        System.out.println(all);
    }

    @Test
    public void test4() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        EmployeeService employeeService = context.getBean("employeeService", EmployeeService.class);
//        employeeService.add(new Employee("E-FF","ff@163.com",0));
//        employeeService.delete(1006);
//        employeeService.update(new Employee(1007,"E-FF","ff@163.com",1));
        System.out.println(employeeService.getAll());
//        System.out.println(employeeService.get(1007));
    }
}