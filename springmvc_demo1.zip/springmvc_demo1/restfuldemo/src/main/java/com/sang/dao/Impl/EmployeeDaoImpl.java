package com.sang.dao.Impl;

import com.sang.dao.EmployeeDao;
import com.sang.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author slzstart
 * @create 2022-08-20 11:39
 */

@Repository
public class EmployeeDaoImpl implements EmployeeDao {
    @Autowired(required = false)
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public void add(Employee employee) {
        String sql = "insert into employee(lastName,email,gender) values(?,?,?)";
        int update = jdbcTemplate.update(sql, employee.getLastName(), employee.getEmail(), employee.getGender());
        System.out.println("成功增加" + update);
    }

    @Override
    public void delete(Integer id) {
        String sql = "delete from employee where id = ?";
        int update = jdbcTemplate.update(sql, id);
        System.out.println("成功删除" + update);

    }

    @Override
    public void update(Employee employee) {
        String sql = "update employee set lastName = ?,email = ?,gender = ? where id = ?";
        int update = jdbcTemplate.update(sql, employee.getLastName(), employee.getEmail(), employee.getGender(), employee.getId());
        System.out.println("成功更新" + update);
    }

    @Override
    public Employee get(Integer id) {
        String sql = "select * from employee where id = ?";
        Employee employee = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<>(Employee.class), id);
        return employee;
    }

    @Override
    public List<Employee> getAll() {
        String sql = "select * from employee";
        List<Employee> query = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Employee.class));
        return query;
    }
}
