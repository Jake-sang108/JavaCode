package com.sang.Service;

import com.sang.dao.EmployeeDao;
import com.sang.dao.Impl.EmployeeDaoImpl;
import com.sang.pojo.Employee;
import com.sun.xml.internal.bind.v2.model.core.ID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.awt.print.Book;
import java.util.Collection;
import java.util.List;

/**
 * @author slzstart
 * @create 2022-08-20 12:28
 */
@Service
public class EmployeeService {
    @Autowired
    private EmployeeDaoImpl employeeDao;

    public EmployeeDaoImpl getEmployeeDao() {
        return employeeDao;
    }

    public void setEmployeeDao(EmployeeDaoImpl employeeDao) {
        this.employeeDao = employeeDao;
    }

    public void add(Employee employee) {
        employeeDao.add(employee);
    }

    public void delete(Integer id) {
        employeeDao.delete(id);
    }

    public void update(Employee employee) {
        employeeDao.update(employee);
    }

    public Employee get(Integer id) {
        return employeeDao.get(id);
    }

    public List<Employee> getAll() {
        return employeeDao.getAll();
    }
}
