package com.sang.dao;

import com.sang.pojo.Employee;
import org.springframework.jdbc.core.JdbcTemplate;

import java.awt.print.Book;
import java.util.Collection;
import java.util.List;

/**
 * @author slzstart
 * @create 2022-08-20 11:39
 */
public interface EmployeeDao {
    public void add(Employee employee);
    public void delete(Integer id);
    public void update(Employee employee);
    public List<Employee> getAll();
    public Employee get(Integer id);
}