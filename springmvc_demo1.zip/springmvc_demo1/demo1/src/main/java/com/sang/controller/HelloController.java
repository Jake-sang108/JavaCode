package com.sang.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.xml.transform.Source;
import java.io.IOException;
import java.util.Arrays;

/**
 * @author slzstart
 * @create 2022-08-15 18:14
 */
@Controller
public class HelloController {
    @RequestMapping("/")
    public String index(){
        return "index";
    }
    @RequestMapping("/hello")
    public String hello(HttpServletRequest servlet ,String username, String password){
//        String username = request.getParameter("username");
//        String password = request.getParameter("password");
        HttpSession session = servlet.getSession();
        servlet.setAttribute("password",password);
        System.out.println("username:" + username +" ,password:" + password);
        return "target";
    }

    @RequestMapping("/testParam")
    public String testParam(
            @RequestParam("username") String user_name, String password, String[] hobby,
            @RequestHeader("Host") String host,
            @CookieValue("JSESSIONID") String JSESSIONID
            ){

        System.out.println("username:" +user_name+",password:"+password+",hobby:" + Arrays.toString(hobby));
        System.out.println(host);
        System.out.println(JSESSIONID);
        return "target";
    }

    @RequestMapping("/testModelAndView")
    public ModelAndView testModelAndView(String username,String password,String sex,String age,String email){
        ModelAndView mav = new ModelAndView();
        mav.addObject("username",username);
        mav.addObject("password",password);
        mav.addObject("sex",sex);
        mav.addObject("age",age);
        mav.addObject("email",email);
        mav.setViewName("target");
        return mav;
    }

    @RequestMapping("/testApplication")
    public String testApplication(HttpSession session, String username,String sex){
        ServletContext context = session.getServletContext();
        context.setAttribute("username",username);
        context.setAttribute("sex",sex);
        return "target";
    }

    @RequestMapping("/testException")
    public String testException(){
        System.out.println(1/0);
        return "target";
    }


}
