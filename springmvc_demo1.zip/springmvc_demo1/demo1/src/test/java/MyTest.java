import org.junit.Test;

/**
 * @author slzstart
 * @create 2022-08-18 12:11
 */
public class MyTest {
    @Test
    public void test1(){
        int i = 1;
        i = i++;
        int j = i++;//j = 1
        int k = i+ ++i * i++;//i = 2
        // 2 + 3 * 3 = 11

        System.out.println(i);
        System.out.println(j);
        System.out.println(k);

    }
}
