package com.sang.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * @author slzstart
 * @create 2022-08-19 21:51
 */
@Controller
public class TestController {
    @RequestMapping("/")
    public String index(){
        return "index";
    }

    @RequestMapping("/hello")
    public String hello(HttpServletRequest servlet , String username, String password){
//        String username = request.getParameter("username");
//        String password = request.getParameter("password");
        HttpSession session = servlet.getSession();
        servlet.setAttribute("password",password);
        System.out.println("username:" + username +" ,password:" + password);
        return "target";
    }

    @RequestMapping("/testException")
    public String testException(){
        System.out.println(1/0);
        return "target";
    }
}
