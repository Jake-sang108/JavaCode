package com.sang.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author slzstart
 * @create 2022-08-19 11:11
 */
@Configuration
public class SpringConfig {

}
